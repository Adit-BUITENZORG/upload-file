# SPONGEBOB BOTS
- install module
```
pkg install python
pip install rsa
pip install six
pip install requests
pip install thrift==0.11.0
pip install bs4
```
- runner
```
cd spongebob
python3 spongebob.py
```
- LINE UPDATE
agustus 2018
# [TUTORIAL](https://www.youtube.com/channel/UCycBrqSWEHdk-slnhUmGWiQ)
![Prankbots](spongebob.png) ![prank](patrick.png)
V2.1 last update::
- 12/agustus/2018
# official bots
<a href="https://line.me/R/ti/p/%40gnh2780p"><img height="36" border="0" alt="PrankBots" src="https://scdn.line-apps.com/n/line_add_friends/btn/en.png"></a>
# Creator bots
<a href="https://line.me/R/ti/p/~adiputra.95"><img height="36" border="0" alt="Add Friend" src="https://scdn.line-apps.com/n/line_add_friends/btn/en.png"></a>
